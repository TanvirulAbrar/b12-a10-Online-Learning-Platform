import { NavLink } from "react-router";

const CourseCard = ({ course }) => {
  const { _id, title, image, price, category, description, isFeatured } = course;

  return (
    <NavLink to={`/courses/${_id}`} className="block h-full">
      <div className="bg-white dark:bg-gray-900 rounded-xl overflow-hidden border border-[#f0f2f4] dark:border-gray-800 flex flex-col hover:shadow-lg transition-shadow h-full">
        <div className="relative h-48 w-full overflow-hidden flex-shrink-0">
          <img 
            className="w-full h-full object-cover" 
            src={image} 
            alt={title}
          />
          <div className="absolute top-3 left-3 flex gap-2">
            <span className="px-2 py-1 bg-amber-500 text-white text-[10px] font-bold rounded uppercase">
              Premium
            </span>
            {isFeatured && (
              <span className="px-2 py-1 bg-[#137fec] text-white text-[10px] font-bold rounded uppercase">
                Featured
              </span>
            )}
          </div>
        </div>
        
        <div className="p-5 flex flex-col flex-1">
          <span className="text-[#137fec] text-xs font-bold uppercase tracking-wider mb-2">
            {category}
          </span>
          <h3 className="text-[#111418] dark:text-white font-bold text-lg mb-2 line-clamp-2 min-h-[3.5rem] leading-tight">
            {title}
          </h3>
          <p className="text-[#617589] dark:text-gray-400 text-sm mb-4 line-clamp-3 min-h-[4.5rem] leading-relaxed flex-1">
            {description || "Learn the fundamentals and advanced concepts in this comprehensive course designed for professional growth."}
          </p>
          
          <div className="mt-auto flex items-center justify-between pt-4 border-t border-[#f0f2f4] dark:border-gray-800">
            <span className="text-[#111418] dark:text-white font-bold text-xl">
              ${price}
            </span>
            <button className="bg-[#137fec] hover:bg-[#137fec]/90 text-white px-4 py-2 rounded-lg text-sm font-bold transition-colors">
              More Details
            </button>
          </div>
        </div>
      </div>
    </NavLink>
  );
};

export default CourseCard;
