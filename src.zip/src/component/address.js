export const addressOfServer = "https://server-a10-seven.vercel.app";
// export const addressOfServer = "http://localhost:3000";
