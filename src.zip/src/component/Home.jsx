import React, { useEffect, useState } from "react";
import useAxios from "./useAxios";
import Banner from "./Banner/Banner";
import PopularCourses from "./Popular Courses/PopularCourses";
import TopInstructor from "./Home/TopInstructor";
import WhyChooseUs from "./Home/WhyChooseUs";
import Testimonials from "./Home/Testimonials";
import CourseCategories from "./Home/CourseCategories";
import FAQ from "./Home/FAQ";
import Statistics from "./Home/Statistics";
import HowItWorks from "./Home/HowItWorks";
import CTASection from "./Home/CTASection";

const Home = () => {
  const axios = useAxios();
  const [courses, setCourses] = useState([]);

  useEffect(() => {
    if (courses.length > 0) return;
    axios
      .get("/courses")
      .then((res) => setCourses(res.data))
      .catch((err) => console.error(err));
  }, [courses.length, axios]);

  return (
    <div className="min-h-screen bg-background-light dark:bg-background-dark font-display text-neutral-900 dark:text-neutral-100 transition-colors duration-300">
      <Banner />
      <HowItWorks />
      <CourseCategories />
      <CTASection />
      <PopularCourses courses={courses} />
      <TopInstructor />
      <WhyChooseUs />
      <Testimonials />
      <FAQ />
      <Statistics />
    </div>
  );
};

export default Home;
