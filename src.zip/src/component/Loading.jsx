import { School, Sparkles, BookOpen, Award, GraduationCap } from "lucide-react";

const Loading = () => {
  return (
    <div className="bg-[#f6f7f8] dark:bg-[#101922] text-[#111418] dark:text-white transition-colors duration-300">
      <div className="relative flex h-screen w-full flex-col items-center justify-center overflow-x-hidden px-4">
        <div className="layout-container flex w-full max-w-[480px] flex-col items-center gap-8">
          <div className="flex flex-col items-center justify-center gap-4">
            <div className="relative flex items-center justify-center">
              <div className="w-24 h-24 rounded-full border-4 border-[#137fec]/20 flex items-center justify-center">
                <div className="w-16 h-16 rounded-full border-4 border-[#137fec] border-t-transparent animate-spin">
                  <div className="flex h-full w-full items-center justify-center">
                    <School className="text-[#137fec] size-10" />
                  </div>
                </div>
              </div>
              <div className="absolute -top-2 -right-2 bg-[#137fec] text-white p-1 rounded-full shadow-lg">
                <Sparkles className="size-3" />
              </div>
            </div>
            <h1 className="text-2xl font-bold tracking-tight text-[#111418] dark:text-white">O-Learn</h1>
          </div>

          <div className="w-full flex flex-col gap-3">
            <div className="flex gap-6 justify-between items-end">
              <p className="text-[#111418] dark:text-gray-200 text-base font-medium leading-normal">Preparing your workspace...</p>
              <p className="text-[#137fec] text-sm font-semibold leading-normal">68%</p>
            </div>
            <div className="rounded-full bg-gray-200 dark:bg-gray-700 h-2 w-full overflow-hidden">
              <div className="h-full rounded-full bg-[#137fec] transition-all duration-300" style={{ width: "68%" }}></div>
            </div>
            <p className="text-[#617589] dark:text-gray-400 text-xs font-normal leading-normal text-center">Optimizing your personalized learning path</p>
          </div>

          <div className="layout-content-container flex flex-col items-center max-w-[400px]">
            <div className="bg-white dark:bg-gray-800/50 p-6 rounded-xl border border-gray-100 dark:border-gray-700 shadow-sm italic">
              <p className="text-[#111418] dark:text-gray-200 text-base font-normal leading-relaxed text-center">
                "The expert in anything was once a beginner."
              </p>
            </div>
          </div>

          <div className="flex flex-col items-center gap-2 pt-4">
            <div className="flex gap-4">
              <BookOpen className="text-[#137fec]/40 size-6" />
              <Award className="text-[#137fec]/40 size-6" />
              <GraduationCap className="text-[#137fec]/40 size-6" />
            </div>
          </div>
        </div>

        <div className="absolute bottom-8 text-center">
          <p className="text-[#617589] dark:text-gray-500 text-xs font-medium uppercase tracking-widest">Powered by O-Learn AI</p>
        </div>
      </div>
    </div>
  );
};

export default Loading;
