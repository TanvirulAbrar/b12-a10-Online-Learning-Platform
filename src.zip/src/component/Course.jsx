import { useEffect, useState } from "react";
import CourseCard from "./CourseCard";
import useAxios from "./useAxios";
import Loading from "./Loading";
import { Search, ChevronDown, Filter, LayoutGrid, Database, Code, Smartphone, Terminal, BarChart3, Shield, Brain } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const Course = () => {
  const axios = useAxios();
  const [courses, setCourses] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState("");
  const [filterdata, setfilterdata] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");

  useEffect(() => {
    if (courses.length > 0) {
      return;
    }
    axios
      .get("/courses")
      .then((res) => {
        setCourses(res.data);
        setfilterdata(res.data);
      })
      .catch((err) => console.error(err));
  }, [courses]);

  const [category, setCategory] = useState([]);
  useEffect(() => {
    if (courses) {
      const uniqueCategories = [];
      for (const course of courses) {
        const cat = course.category;
        if (cat && !uniqueCategories.includes(cat)) {
          uniqueCategories.push(cat);
        }
      }
      setCategory(uniqueCategories);
    }
  }, [courses]);

  const findWithWord = (query) => {
    const mdata = courses.filter((item) =>
      item.title.toLowerCase().includes(query.toLowerCase()) ||
      item.category.toLowerCase().includes(query.toLowerCase())
    );
    setfilterdata(mdata);
  };

  const handleSearch = (e) => {
    const query = e.target.value;
    setSearchQuery(query);
    findWithWord(query);
  };

  const handelsort = (type) => {
    if (type === "price High-Low") {
      const sortbyd = [...filterdata].sort(
        (a, b) => Number(b.price) - Number(a.price)
      );
      setfilterdata(sortbyd);
    }
    if (type === "price Low-High") {
      const sortbyd = [...filterdata].sort(
        (a, b) => Number(a.price) - Number(b.price)
      );
      setfilterdata(sortbyd);
    }
    if (type === "Latest") {
      const sortbyd = [...filterdata].sort(
        (a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0)
      );
      setfilterdata(sortbyd);
    }
    if (type === "Popularity") {
      const sortbyd = [...filterdata].sort(
        (a, b) => (b.enrolledCount || 0) - (a.enrolledCount || 0)
      );
      setfilterdata(sortbyd);
    }
  };

  const handelcategory = (cat) => {
    if (cat === "All") {
      setfilterdata(courses);
      setSelectedCategory("");
    } else {
      const filterByCategory = courses.filter((item) => item.category === cat);
      setfilterdata(filterByCategory);
      setSelectedCategory(cat);
    }
  };

  const getCategoryIcon = (categoryName) => {
    const iconMap = {
      "Web Development": Code,
      "Backend": Terminal,
      "Mobile": Smartphone,
      "Database": Database,
      "Data Science": BarChart3,
      "Security": Shield,
      "AI & ML": Brain,
    };
    return iconMap[categoryName] || Code;
  };

  if (courses.length === 0) return <Loading />;

  return (
    <div className="bg-[#f6f7f8] dark:bg-[#101922] text-[#111418] dark:text-white antialiased min-h-screen">
      <div className="flex flex-col min-h-screen">
        <main className="flex-1 w-full max-w-[1440px] mx-auto px-6 py-8">
          {/* Page Heading */}
          <div className="flex flex-col gap-3 mb-8 px-4">
            <h1 className="text-[#111418] dark:text-white text-4xl font-black leading-tight tracking-[-0.033em]">
              Explore All Courses
            </h1>
            <p className="text-[#617589] dark:text-gray-400 text-lg font-normal max-w-2xl">
              Unlock your potential with our comprehensive library of expert-led courses designed for professional growth.
            </p>
          </div>

          {/* Toolbar */}
          <div className="flex flex-col md:flex-row items-center justify-between gap-4 px-4 py-6 bg-white dark:bg-gray-900 rounded-xl mb-8 border border-[#f0f2f4] dark:border-gray-800">
            <div className="flex-1 w-full max-w-lg">
              <div className="relative group">
                <div className="absolute inset-y-0 left-0 flex items-center pl-4 text-[#617589] dark:text-gray-400">
                  <Search className="size-5" />
                </div>
                <input 
                  className="w-full h-12 pl-12 pr-4 bg-[#f6f7f8] dark:bg-[#101922] border-none rounded-lg text-[#111418] dark:text-white focus:ring-2 focus:ring-[#137fec] placeholder:text-[#617589]" 
                  placeholder="Search for courses, skills, or authors..." 
                  type="text"
                  value={searchQuery}
                  onChange={handleSearch}
                />
              </div>
            </div>
            <div className="flex items-center gap-4 w-full md:w-auto">
              <div className="flex items-center gap-2 text-sm font-medium text-[#111418] dark:text-gray-300 whitespace-nowrap">
                <span>Sort by:</span>
                <div className="relative">
                  <select 
                    className="appearance-none bg-[#f0f2f4] dark:bg-[#101922] border-none rounded-lg h-10 px-4 pr-10 text-sm font-bold cursor-pointer focus:ring-[#137fec]"
                    onChange={(e) => handelsort(e.target.value)}
                  >
                    <option value="Latest">Latest</option>
                    <option value="Popularity">Popularity</option>
                    <option value="price Low-High">Price: Low to High</option>
                    <option value="price High-Low">Price: High to Low</option>
                  </select>
                  <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none">
                    <ChevronDown className="size-4" />
                  </div>
                </div>
              </div>
              <button className="p-2 bg-[#f0f2f4] dark:bg-[#101922] rounded-lg text-[#111418] dark:text-white hover:bg-gray-200 transition-all">
                <Filter className="size-5" />
              </button>
            </div>
          </div>

          <div className="flex flex-col lg:flex-row gap-8 px-4">
            {/* Side Navigation Filter */}
            <aside className="w-full lg:w-64 flex-shrink-0">
              <div className="sticky top-24 bg-white dark:bg-gray-900 p-6 rounded-xl border border-[#f0f2f4] dark:border-gray-800">
                <h3 className="text-[#111418] dark:text-white text-lg font-bold mb-6">Categories</h3>
                <nav className="flex flex-col gap-2">
                  <button
                    onClick={() => handelcategory("All")}
                    className={`flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all text-left ${
                      selectedCategory === "" 
                        ? "bg-[#137fec] text-white shadow-md shadow-[#137fec]/20" 
                        : "hover:bg-[#137fec]/10 text-[#111418] dark:text-gray-300 group"
                    }`}
                  >
                    <LayoutGrid className={`size-5 ${selectedCategory === "" ? "text-white" : "text-gray-500 group-hover:text-[#137fec]"}`} />
                    <span className={`text-sm font-medium ${selectedCategory === "" ? "text-white" : "group-hover:text-[#137fec]"}`}>
                      All Courses
                    </span>
                  </button>
                  
                  {category.map((cat) => {
                    const IconComponent = getCategoryIcon(cat);
                    return (
                      <button
                        key={cat}
                        onClick={() => handelcategory(cat)}
                        className={`flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all text-left ${
                          selectedCategory === cat 
                            ? "bg-[#137fec] text-white shadow-md shadow-[#137fec]/20" 
                            : "hover:bg-[#137fec]/10 text-[#111418] dark:text-gray-300 group"
                        }`}
                      >
                        <IconComponent className={`size-5 ${selectedCategory === cat ? "text-white" : "text-gray-500 group-hover:text-[#137fec]"}`} />
                        <span className={`text-sm font-medium ${selectedCategory === cat ? "text-white" : "group-hover:text-[#137fec]"}`}>
                          {cat}
                        </span>
                      </button>
                    );
                  })}
                </nav>
              </div>
            </aside>

            {/* Course Grid */}
            <div className="flex-1">
              {filterdata.length === 0 ? (
                <div className="flex flex-col items-center gap-8 py-16">
                  {/* No Search Results State */}
                  <div className="relative w-full max-w-[400px] aspect-video rounded-xl overflow-hidden bg-gradient-to-br from-[#137fec]/10 to-[#137fec]/5 flex items-center justify-center border border-[#137fec]/10">
                    <div className="flex flex-col items-center text-[#137fec]/40">
                      <Search className="size-20" />
                    </div>
                  </div>
                  
                  <div className="flex max-w-[540px] flex-col items-center gap-4">
                    <h1 className="text-[#111418] dark:text-white text-3xl font-bold leading-tight tracking-[-0.015em] text-center">
                      {searchQuery 
                        ? `Oops! We couldn't find any courses for "${searchQuery}"`
                        : selectedCategory 
                          ? `No courses found in "${selectedCategory}"`
                          : "No courses found"
                      }
                    </h1>
                    <p className="text-gray-600 dark:text-gray-400 text-lg font-normal leading-relaxed text-center">
                      Try adjusting your search query, removing filters, or explore one of our most popular learning paths below.
                    </p>
                  </div>
                  
                  <div className="flex gap-4">
                    <button 
                      onClick={() => {
                        setSearchQuery("");
                        setSelectedCategory("");
                        setfilterdata(courses);
                      }}
                      className="flex min-w-[160px] cursor-pointer items-center justify-center rounded-lg h-12 px-6 bg-[#137fec] text-white text-base font-bold shadow-md hover:bg-[#137fec]/90 transition-all"
                    >
                      Reset Search
                    </button>
                    <button 
                      onClick={() => {
                        setSearchQuery("");
                        setSelectedCategory("");
                        setfilterdata(courses);
                      }}
                      className="flex min-w-[160px] cursor-pointer items-center justify-center rounded-lg h-12 px-6 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-[#111418] dark:text-white text-base font-bold hover:bg-gray-50 dark:hover:bg-gray-700 transition-all"
                    >
                      View All Courses
                    </button>
                  </div>
                </div>
              ) : (
                <motion.div 
                  className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ duration: 0.3 }}
                >
                  <AnimatePresence>
                    {filterdata.map((course, index) => (
                      <motion.div
                        key={course._id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -20 }}
                        transition={{ duration: 0.3, delay: index * 0.1 }}
                        className="h-full"
                      >
                        <CourseCard course={course} />
                      </motion.div>
                    ))}
                  </AnimatePresence>
                </motion.div>
              )}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default Course;