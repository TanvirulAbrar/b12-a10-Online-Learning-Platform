import { use } from "react";
import { NavLink } from "react-router";
import { toast } from "react-toastify";
import AuthContext from "../context/AuthContext";
import { motion } from "framer-motion";
import { School, Mail, ArrowLeft, ChevronDown } from "lucide-react";

const ForgetPassWord = () => {
  const { forgetPassWord } = use(AuthContext);

  const handelForgetPassward = (e) => {
    e.preventDefault();
    const email = e.target.email.value;
    
    if (!email) {
      toast.error("Please enter your email address");
      return;
    }

    toast.info("Check your email for reset instructions");
    forgetPassWord(email)
      .then(() => {
        toast.success("Password reset email sent successfully!");
      })
      .catch((error) => {
        console.log(error);
        toast.error("Failed to send reset email. Please try again.");
      });
  };

  return (
    <div className="bg-[#f6f7f8] dark:bg-[#101922] min-h-screen flex flex-col font-display">
      {/* Header / TopNavBar */}
      <header className="flex items-center justify-between whitespace-nowrap border-b border-solid border-[#dbe0e6] dark:border-[#2a3541] px-10 py-3 bg-white dark:bg-[#1a242f]">
        <div className="flex items-center gap-4">
          <div className="size-8 bg-[#137fec] rounded-lg flex items-center justify-center text-white">
            <School className="size-5" />
          </div>
          <h2 className="text-[#111418] dark:text-white text-xl font-bold leading-tight tracking-[-0.015em]">O-Learn</h2>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-sm text-[#617589] dark:text-[#94a3b8]">English</span>
          <ChevronDown className="text-[#617589] dark:text-[#94a3b8] size-4" />
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex items-center justify-center p-6 bg-gradient-to-br from-[#f6f7f8] via-[#f6f7f8] to-[#137fec]/5 dark:from-[#101922] dark:via-[#101922] dark:to-[#137fec]/10">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full max-w-[480px] bg-white dark:bg-[#1a242f] rounded-xl shadow-xl border border-[#dbe0e6] dark:border-[#2a3541] overflow-hidden"
        >
          <div className="p-8">
            {/* Icon and Headline */}
            <div className="flex justify-center mb-4">
              <div className="bg-[#137fec]/10 p-4 rounded-full">
                <Mail className="text-[#137fec] size-10" />
              </div>
            </div>
            <h1 className="text-[#111418] dark:text-white tracking-light text-[28px] font-bold leading-tight text-center pb-2">
              Forgot Password?
            </h1>

            {/* Body Text */}
            <p className="text-[#617589] dark:text-[#94a3b8] text-base font-normal leading-normal pb-8 text-center">
              Enter your email address and we'll send you instructions to reset your password.
            </p>

            {/* Form */}
            <form onSubmit={handelForgetPassward}>
              <div className="flex flex-col gap-4 py-3">
                <label className="flex flex-col w-full">
                  <p className="text-[#111418] dark:text-white text-sm font-semibold leading-normal pb-2">Email Address</p>
                  <div className="relative">
                    <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-[#617589] dark:text-[#94a3b8] size-5" />
                    <input 
                      name="email"
                      className="form-input flex w-full rounded-lg text-[#111418] dark:text-white focus:outline-0 focus:ring-2 focus:ring-[#137fec]/50 border border-[#dbe0e6] dark:border-[#2a3541] bg-white dark:bg-[#101922] h-14 placeholder:text-[#617589] dark:placeholder:text-[#4a5568] pl-12 pr-4 text-base font-normal leading-normal transition-all" 
                      placeholder="e.g. name@domain.com" 
                      type="email"
                      required
                    />
                  </div>
                </label>
              </div>

              {/* Submit Button */}
              <div className="flex py-4">
                <button 
                  type="submit"
                  className="flex w-full cursor-pointer items-center justify-center overflow-hidden rounded-lg h-12 px-5 bg-[#137fec] hover:bg-[#137fec]/90 text-white text-base font-bold leading-normal tracking-[0.015em] transition-colors shadow-md shadow-[#137fec]/20"
                >
                  <span className="truncate">Send Reset Link</span>
                </button>
              </div>

              {/* Back to Login Link */}
              <div className="text-center pt-4">
                <NavLink 
                  to="/login"
                  className="text-[#137fec] hover:text-[#137fec]/80 text-sm font-semibold flex items-center justify-center gap-1"
                >
                  <ArrowLeft className="size-4" />
                  Back to Login
                </NavLink>
              </div>
            </form>
          </div>

          <div className="bg-[#f6f7f8] dark:bg-[#101922]/50 p-4 text-center border-t border-[#dbe0e6] dark:border-[#2a3541]">
            <p className="text-[#617589] dark:text-[#94a3b8] text-xs">
              Need help? <a className="text-[#137fec] hover:underline" href="#">Contact Support</a>
            </p>
          </div>
        </motion.div>
      </main>

      {/* Footer */}
      <footer className="py-6 text-center bg-white dark:bg-[#1a242f] border-t border-[#dbe0e6] dark:border-[#2a3541]">
        <p className="text-[#617589] dark:text-[#94a3b8] text-sm">O-Learn Platform © 2024. All rights reserved.</p>
      </footer>
    </div>
  );
};

export default ForgetPassWord;
