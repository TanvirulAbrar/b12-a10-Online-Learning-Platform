import { useNavigate } from "react-router";
import useAuth from "../../hooks/useAuth";
// import useAuth from "../hooks/useAuth";

const Banner = () => {
  const navigate = useNavigate();
  const { user } = useAuth();

  return (
    <div className="bg-[#f6f7f8] dark:bg-[#101922] font-display text-[#111418] dark:text-white transition-colors duration-200">
      <main className="max-w-[1280px] mx-auto px-4 sm:px-10">
        {/* Hero Section */}
        <section className="py-12 md:py-20 lg:py-24">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="flex flex-col gap-8">
              <div className="flex flex-col gap-4">
                <span className="inline-block px-3 py-1 bg-[#137fec]/10 text-[#137fec] text-xs font-bold uppercase tracking-wider rounded-full w-fit">Expert-Led Learning</span>
                <h1 className="text-4xl md:text-6xl font-black leading-tight tracking-tight">
                  Unlock Your Potential with <span className="text-[#137fec]">Premium</span> Courses
                </h1>
                <p className="text-lg text-[#617589] dark:text-gray-400 max-w-lg">
                  Master new skills with our expert-led online courses designed for your career growth. Join over 2 million students today.
                </p>
              </div>
              <div className="flex flex-wrap gap-4">
                <button 
                  onClick={() => user ? navigate("/dashboard") : navigate("/courses")}
                  className="flex min-w-[160px] cursor-pointer items-center justify-center rounded-xl h-14 px-6 bg-[#137fec] text-white text-base font-bold shadow-lg shadow-[#137fec]/25"
                >
                  {user ? "Go to Dashboard" : "Get Started"}
                </button>
                <button 
                  onClick={() => navigate("/courses")}
                  className="flex min-w-[160px] cursor-pointer items-center justify-center rounded-xl h-14 px-6 bg-white dark:bg-gray-800 border border-[#dbe0e6] dark:border-gray-700 text-base font-bold"
                >
                  Browse Courses
                </button>
              </div>
              <div className="flex items-center gap-4">
                <div className="flex -space-x-3">
                  <img className="w-10 h-10 rounded-full border-2 border-white dark:border-[#101922]" src="https://images.unsplash.com/photo-1494790108755-2616b612b786?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=687&q=80" alt="User avatar thumbnail 1" />
                  <img className="w-10 h-10 rounded-full border-2 border-white dark:border-[#101922]" src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=687&q=80" alt="User avatar thumbnail 2" />
                  <img className="w-10 h-10 rounded-full border-2 border-white dark:border-[#101922]" src="https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80" alt="User avatar thumbnail 3" />
                  <div className="w-10 h-10 rounded-full bg-[#137fec] flex items-center justify-center text-white text-[10px] font-bold border-2 border-white dark:border-[#101922]">2M+</div>
                </div>
                <p className="text-sm font-medium text-[#617589]">Trusted by students worldwide</p>
              </div>
            </div>
            <div className="relative">
              <div className="w-full aspect-square md:aspect-video lg:aspect-square bg-center bg-cover rounded-3xl shadow-2xl" style={{backgroundImage: 'url("https://images.unsplash.com/photo-1522202176988-66273c2fd55f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2071&q=80")'}}></div>
              <div className="absolute -bottom-6 -left-6 bg-white dark:bg-gray-800 p-6 rounded-2xl shadow-xl hidden md:block">
                <div className="flex items-center gap-4">
                  <div className="p-3 bg-green-100 text-green-600 rounded-lg">
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                    </svg>
                  </div>
                  <div>
                    <p className="text-2xl font-bold">98%</p>
                    <p className="text-xs text-[#617589]">Success Rate</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Trust Section */}
        <section className="py-12 border-y border-[#f0f2f4] dark:border-gray-800">
          <p className="text-center text-sm font-medium text-[#617589] mb-8 uppercase tracking-widest">Our Students Work At</p>
          <div className="flex flex-wrap justify-center items-center gap-12 opacity-50 grayscale hover:grayscale-0 transition-all">
            <div className="flex items-center gap-2 text-2xl font-bold">Google</div>
            <div className="flex items-center gap-2 text-2xl font-bold">Microsoft</div>
            <div className="flex items-center gap-2 text-2xl font-bold">Netflix</div>
            <div className="flex items-center gap-2 text-2xl font-bold">Meta</div>
            <div className="flex items-center gap-2 text-2xl font-bold">Amazon</div>
          </div>
        </section>

        {/* How It Works */}
        <section className="py-16">
          <h2 className="text-3xl font-bold mb-12 text-center">How It Works</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="flex flex-col gap-4 p-8 rounded-2xl border border-[#dbe0e6] dark:border-gray-800 bg-white dark:bg-gray-900/50 hover:shadow-xl transition-shadow group">
              <div className="w-12 h-12 bg-[#137fec]/10 text-[#137fec] flex items-center justify-center rounded-xl group-hover:bg-[#137fec] group-hover:text-white transition-colors">
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z" />
                </svg>
              </div>
              <div>
                <h3 className="text-lg font-bold mb-1">Sign Up</h3>
                <p className="text-[#617589] text-sm">Create your personal account to get personalized recommendations.</p>
              </div>
            </div>
            <div className="flex flex-col gap-4 p-8 rounded-2xl border border-[#dbe0e6] dark:border-gray-800 bg-white dark:bg-gray-900/50 hover:shadow-xl transition-shadow group">
              <div className="w-12 h-12 bg-[#137fec]/10 text-[#137fec] flex items-center justify-center rounded-xl group-hover:bg-[#137fec] group-hover:text-white transition-colors">
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
              </div>
              <div>
                <h3 className="text-lg font-bold mb-1">Browse</h3>
                <p className="text-[#617589] text-sm">Explore thousands of courses across hundreds of unique categories.</p>
              </div>
            </div>
            <div className="flex flex-col gap-4 p-8 rounded-2xl border border-[#dbe0e6] dark:border-gray-800 bg-white dark:bg-gray-900/50 hover:shadow-xl transition-shadow group">
              <div className="w-12 h-12 bg-[#137fec]/10 text-[#137fec] flex items-center justify-center rounded-xl group-hover:bg-[#137fec] group-hover:text-white transition-colors">
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.746 0 3.332.477 4.5 1.253v13C19.832 18.477 18.246 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                </svg>
              </div>
              <div>
                <h3 className="text-lg font-bold mb-1">Learn</h3>
                <p className="text-[#617589] text-sm">Study at your own pace with lifetime access to all course materials.</p>
              </div>
            </div>
            <div className="flex flex-col gap-4 p-8 rounded-2xl border border-[#dbe0e6] dark:border-gray-800 bg-white dark:bg-gray-900/50 hover:shadow-xl transition-shadow group">
              <div className="w-12 h-12 bg-[#137fec]/10 text-[#137fec] flex items-center justify-center rounded-xl group-hover:bg-[#137fec] group-hover:text-white transition-colors">
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z" />
                </svg>
              </div>
              <div>
                <h3 className="text-lg font-bold mb-1">Earn Certificate</h3>
                <p className="text-[#617589] text-sm">Get recognized for your hard work with industry-standard certification.</p>
              </div>
            </div>
          </div>
        </section>

        {/* Promo Banner */}
        <section className="py-12">
          <div className="relative bg-[#137fec] rounded-3xl overflow-hidden p-8 md:p-16 flex flex-col md:flex-row items-center justify-between text-white gap-8">
            <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -mr-32 -mt-32"></div>
            <div className="relative z-10">
              <p className="text-sm font-bold uppercase tracking-widest mb-2 opacity-80">New Year Launch Offer</p>
              <h2 className="text-3xl md:text-5xl font-black mb-4">Save up to 50% OFF</h2>
              <p className="text-white/80 max-w-md">Limited time offer on all premium specialization tracks. Start your journey today.</p>
            </div>
            <div className="relative z-10 flex flex-col items-center gap-4">
              <div className="flex gap-4">
                <div className="bg-white/20 backdrop-blur text-center p-3 rounded-xl min-w-[70px]">
                  <p className="text-2xl font-bold">02</p>
                  <p className="text-[10px] uppercase font-bold">Days</p>
                </div>
                <div className="bg-white/20 backdrop-blur text-center p-3 rounded-xl min-w-[70px]">
                  <p className="text-2xl font-bold">14</p>
                  <p className="text-[10px] uppercase font-bold">Hrs</p>
                </div>
                <div className="bg-white/20 backdrop-blur text-center p-3 rounded-xl min-w-[70px]">
                  <p className="text-2xl font-bold">59</p>
                  <p className="text-[10px] uppercase font-bold">Min</p>
                </div>
              </div>
              <button 
                onClick={() => navigate("/courses")}
                className="w-full bg-white text-[#137fec] font-bold py-4 px-8 rounded-xl shadow-lg hover:bg-[#f6f7f8] transition-colors"
              >
                Claim Discount Now
              </button>
            </div>
          </div>
        </section>

        {/* Top Categories */}
        <section className="py-16">
          <div className="flex justify-between items-end mb-10">
            <div>
              <h2 className="text-3xl font-bold">Top Categories</h2>
              <p className="text-[#617589]">Explore our wide range of topics</p>
            </div>
            <button 
              onClick={() => navigate("/courses")}
              className="text-[#137fec] font-bold text-sm hover:underline"
            >
              View All
            </button>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            <div className="p-6 bg-white dark:bg-gray-800 rounded-2xl flex flex-col items-center gap-3 text-center hover:shadow-lg transition-all cursor-pointer border border-[#f0f2f4] dark:border-gray-700">
              <svg className="w-10 h-10 text-[#137fec]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" />
              </svg>
              <span className="font-bold text-sm">Web Dev</span>
            </div>
            <div className="p-6 bg-white dark:bg-gray-800 rounded-2xl flex flex-col items-center gap-3 text-center hover:shadow-lg transition-all cursor-pointer border border-[#f0f2f4] dark:border-gray-700">
              <svg className="w-10 h-10 text-[#137fec]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7M4 7c0 2.21 3.582 4 8 4s8-1.79 8-4M4 7c0-2.21 3.582-4 8-4s8 1.79 8 4m0 5c0 2.21-3.582 4-8 4s-8-1.79-8-4" />
              </svg>
              <span className="font-bold text-sm">Data Science</span>
            </div>
            <div className="p-6 bg-white dark:bg-gray-800 rounded-2xl flex flex-col items-center gap-3 text-center hover:shadow-lg transition-all cursor-pointer border border-[#f0f2f4] dark:border-gray-700">
              <svg className="w-10 h-10 text-[#137fec]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z" />
              </svg>
              <span className="font-bold text-sm">Mobile Dev</span>
            </div>
            <div className="p-6 bg-white dark:bg-gray-800 rounded-2xl flex flex-col items-center gap-3 text-center hover:shadow-lg transition-all cursor-pointer border border-[#f0f2f4] dark:border-gray-700">
              <svg className="w-10 h-10 text-[#137fec]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zM21 5a2 2 0 00-2-2h-4a2 2 0 00-2 2v12a4 4 0 004 4 4 4 0 004-4V5z" />
              </svg>
              <span className="font-bold text-sm">Design</span>
            </div>
            <div className="p-6 bg-white dark:bg-gray-800 rounded-2xl flex flex-col items-center gap-3 text-center hover:shadow-lg transition-all cursor-pointer border border-[#f0f2f4] dark:border-gray-700">
              <svg className="w-10 h-10 text-[#137fec]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
              </svg>
              <span className="font-bold text-sm">Marketing</span>
            </div>
            <div className="p-6 bg-white dark:bg-gray-800 rounded-2xl flex flex-col items-center gap-3 text-center hover:shadow-lg transition-all cursor-pointer border border-[#f0f2f4] dark:border-gray-700">
              <svg className="w-10 h-10 text-[#137fec]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2-2v2m8 0H8m8 0v2a2 2 0 01-2 2H10a2 2 0 01-2-2V6m8 0H8m0 0H4a2 2 0 00-2 2v6a2 2 0 002 2h16a2 2 0 002-2V8a2 2 0 00-2-2h-4" />
              </svg>
              <span className="font-bold text-sm">Business</span>
            </div>
          </div>
        </section>

        {/* Stats & CTA */}
        <section className="py-20">
          <div className="bg-[#137fec] rounded-3xl p-12 text-white text-center relative overflow-hidden">
            <div className="absolute inset-0 opacity-10" style={{backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)', backgroundSize: '32px 32px'}}></div>
            <div className="relative z-10">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
                <div>
                  <p className="text-4xl md:text-5xl font-black mb-2">2M+</p>
                  <p className="text-white/70 font-medium">Students</p>
                </div>
                <div>
                  <p className="text-4xl md:text-5xl font-black mb-2">15k+</p>
                  <p className="text-white/70 font-medium">Courses</p>
                </div>
                <div>
                  <p className="text-4xl md:text-5xl font-black mb-2">500k+</p>
                  <p className="text-white/70 font-medium">Hours of Content</p>
                </div>
              </div>
              <h2 className="text-3xl md:text-4xl font-bold mb-8">Ready to start your learning journey?</h2>
              <button 
                onClick={() => user ? navigate("/dashboard") : navigate("/courses")}
                className="bg-white text-[#137fec] px-10 py-4 rounded-xl font-bold text-lg shadow-xl hover:scale-105 transition-transform"
              >
                {user ? "Continue Learning" : "Get Started Now"}
              </button>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
};

export default Banner;
