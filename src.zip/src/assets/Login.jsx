import { use, useState } from "react";
import { Eye, EyeOff, Users } from "lucide-react";
import AuthContext from "../context/AuthContext";
import { NavLink, useLocation, useNavigate } from "react-router";
import { toast } from "react-toastify";

const Login = () => {
  const { setloading, signin, signinWthGoogle } = use(AuthContext);
  const [isOk, setisOk] = useState("");
  const [eye, seteye] = useState(false);
  const [rememberMe, setRememberMe] = useState(false);

  const navigate = useNavigate();
  const location = useLocation();

  const handelloginwithgoogle = (e) => {
    e.preventDefault();
    signinWthGoogle()
      .then(() => {
        toast.success("Login successful!");
        navigate(location.state || "/");
      })
      .catch(console.log);
  };

  const handellogin = (e) => {
    e.preventDefault();
    const email = e.target.email.value;
    const password = e.target.password.value;

    if (!email || !password) {
      toast.error("Please fill in all fields");
      setisOk("Please fill in all fields");
      return;
    }

    signin(email, password)
      .then(() => {
        e.target.reset();
        toast.success("Login successful!");
        setisOk("");
        navigate(location.state || "/");
      })
      .catch((error) => {
        setisOk(error.message);
        setloading(false);
        toast.error("Email or password error");
      });
  };

  return (
    <div className="bg-[#f6f7f8] dark:bg-[#101922] font-display">
      <div className="relative flex h-screen w-full flex-col overflow-hidden">
        <div className="layout-container flex h-full grow flex-col">
          {/* Main Content: Split Layout */}
          <main className="flex flex-1 overflow-hidden">
            {/* Left Side: Hero Image & Quote */}
            <div className="hidden lg:flex lg:w-1/2 relative flex-col justify-center p-20 text-white">
              <div 
                className="absolute inset-0 z-0 bg-cover bg-center" 
                style={{
                  backgroundImage: "url('https://images.unsplash.com/photo-1481627834876-b7833e8f5570?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80')"
                }}
              >
                <div className="absolute inset-0 bg-black/50"></div>
              </div>
              <div className="relative z-10">
                <div className="flex items-center gap-3 mb-12">
                  <div className="size-8 bg-[#137fec] rounded-lg flex items-center justify-center text-white">
                    <svg fill="none" viewBox="0 0 24 24" stroke="currentColor" className="size-5">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.746 0 3.332.477 4.5 1.253v13C19.832 18.477 18.246 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                    </svg>
                  </div>
                  <h1 className="text-2xl font-bold tracking-tight">O-Learn</h1>
                </div>
                <div className="max-w-md">
                  <h2 className="text-4xl font-black leading-tight mb-6">
                    The beautiful thing about learning is that nobody can take it away from you.
                  </h2>
                  <p className="text-xl font-medium text-white/90 mb-8">— B.B. King</p>
                  <div className="inline-flex items-center gap-2 bg-white/20 backdrop-blur-md px-6 py-3 rounded-full border border-white/30">
                    <Users className="text-[#137fec] size-5" />
                    <span className="text-sm font-bold">Join 20k+ learners today</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Side: Login Form */}
            <div className="w-full lg:w-1/2 flex flex-col justify-center items-center bg-white dark:bg-[#101922] p-8 md:p-16">
              <div className="w-full max-w-[440px] space-y-8">
                <div className="space-y-2">
                  <h2 className="text-3xl font-black text-[#111418] dark:text-white">Welcome Back</h2>
                  <p className="text-[#617589] dark:text-[#a0b3c5] text-base">Sign in to continue your learning journey</p>
                </div>

                {isOk && (
                  <div className="p-3 rounded-lg bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800">
                    <p className="text-red-600 dark:text-red-400 text-sm">{isOk}</p>
                  </div>
                )}

                <form onSubmit={handellogin} className="space-y-5">
                  {/* Email Field */}
                  <div className="space-y-2">
                    <label className="text-[#111418] dark:text-white text-base font-medium leading-normal">Email Address</label>
                    <input 
                      name="email"
                      className="form-input flex w-full min-w-0 resize-none overflow-hidden rounded-lg text-[#111418] dark:text-white focus:outline-0 focus:ring-0 border border-[#dbe0e6] dark:border-[#303f4e] bg-white dark:bg-[#1a2632] focus:border-[#137fec] h-14 placeholder:text-[#617589] p-[15px] text-base font-normal" 
                      placeholder="Enter your email" 
                      type="email"
                    />
                  </div>

                  {/* Password Field */}
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <label className="text-[#111418] dark:text-white text-base font-medium leading-normal">Password</label>
                      <NavLink to="/forgetpassword" className="text-[#137fec] text-sm font-semibold hover:underline">
                        Forgot Password?
                      </NavLink>
                    </div>
                    <div className="relative">
                      <input 
                        name="password"
                        className="form-input flex w-full min-w-0 resize-none overflow-hidden rounded-lg text-[#111418] dark:text-white focus:outline-0 focus:ring-0 border border-[#dbe0e6] dark:border-[#303f4e] bg-white dark:bg-[#1a2632] focus:border-[#137fec] h-14 placeholder:text-[#617589] p-[15px] pr-12 text-base font-normal" 
                        placeholder="Enter your password" 
                        type={eye ? "text" : "password"}
                      />
                      <button 
                        className="absolute right-4 top-1/2 -translate-y-1/2 text-[#617589]" 
                        type="button"
                        onClick={() => seteye(!eye)}
                      >
                        {eye ? <EyeOff className="size-5" /> : <Eye className="size-5" />}
                      </button>
                    </div>
                  </div>

                  {/* Remember Me */}
                  <div className="flex items-center">
                    <label className="flex gap-x-3 items-center cursor-pointer">
                      <input 
                        className="h-5 w-5 rounded border-[#dbe0e6] dark:border-[#303f4e] border-2 bg-transparent text-[#137fec] checked:bg-[#137fec] checked:border-[#137fec] focus:ring-0 focus:ring-offset-0 focus:outline-none" 
                        type="checkbox"
                        checked={rememberMe}
                        onChange={(e) => setRememberMe(e.target.checked)}
                      />
                      <span className="text-[#111418] dark:text-white text-base font-normal">Remember me for 30 days</span>
                    </label>
                  </div>

                  {/* Action Buttons */}
                  <div className="space-y-4 pt-2">
                    <button 
                      className="w-full flex cursor-pointer items-center justify-center overflow-hidden rounded-lg h-12 bg-[#137fec] text-white text-base font-bold leading-normal tracking-[0.015em] hover:bg-[#137fec]/90 transition-colors" 
                      type="submit"
                    >
                      Log In
                    </button>

                    <div className="relative py-2">
                      <div className="absolute inset-0 flex items-center">
                        <div className="w-full border-t border-[#dbe0e6] dark:border-[#303f4e]"></div>
                      </div>
                      <div className="relative flex justify-center text-sm">
                        <span className="px-2 bg-white dark:bg-[#101922] text-[#617589]">Or continue with</span>
                      </div>
                    </div>

                    <button 
                      onClick={handelloginwithgoogle}
                      className="w-full flex cursor-pointer items-center justify-center gap-3 overflow-hidden rounded-lg h-12 border border-[#dbe0e6] dark:border-[#303f4e] bg-white dark:bg-[#1a2632] text-[#111418] dark:text-white text-base font-medium hover:bg-gray-50 dark:hover:bg-[#253441] transition-colors" 
                      type="button"
                    >
                      <svg className="w-5 h-5" viewBox="0 0 24 24">
                        <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"></path>
                        <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"></path>
                        <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z" fill="#FBBC05"></path>
                        <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"></path>
                      </svg>
                      Google
                    </button>
                  </div>
                </form>

                <div className="text-center pt-4">
                  <p className="text-[#617589] dark:text-[#a0b3c5] text-base font-normal">
                    Don't have an account? 
                    <NavLink to="/register" className="text-[#137fec] font-bold hover:underline ml-1">Sign Up</NavLink>
                  </p>
                </div>
              </div>
            </div>
          </main>
        </div>
      </div>
    </div>
  );
};

export default Login;